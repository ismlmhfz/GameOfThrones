from django.contrib import admin
from .models import Case
# Register your models here.
admin.site.register(Case)